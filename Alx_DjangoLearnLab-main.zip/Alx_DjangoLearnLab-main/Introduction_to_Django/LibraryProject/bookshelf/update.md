Update the title
book.title = "Nineteen Eighty-Four" book.save() book # Expected output: <Book: Nineteen Eighty-Four>
